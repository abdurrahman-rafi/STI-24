/** RangedAttacker.java
 * Berikut merupakan marker interface untuk pokenimons yang bisa melakukan serangan jarak jauh
 * For your exploration: coba cari tahu lebih lanjut tentang marker interface 
 */
public interface RangedAttacker {
    /** Kira-kira seperti apa yang harus diisi di sini? Coba tebak! :P */
}
