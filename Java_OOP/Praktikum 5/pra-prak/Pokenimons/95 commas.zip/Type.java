/**
 * Type.java
 * Enumerasi tipe unsur untuk Pokenimons.
 */
enum Type { FIRE, WATER, GRASS, ELECTRIC }