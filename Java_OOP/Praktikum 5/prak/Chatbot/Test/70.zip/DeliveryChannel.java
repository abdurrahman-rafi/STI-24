public interface DeliveryChannel {
    String deliver(String response, Chatbot chatbot);
}
