public interface ResponseStyle {
    String format(String baseResponse);
}
