public class Linux extends OperatingSystem{
    public enum Distro {
        UBUNTU, FEDORA, ARCH, DEBIAN
    }
    private Distro distroType;
// public OperatingSystem(String name, String version, String kernelType, double baseScore)
    public Linux(String name, String version, String kernelType, double baseScore, Distro distroType){
        super(name, version, kernelType, baseScore);
        if(distroType == null){
            this.distroType = Distro.UBUNTU;
        }else{
            this.distroType = distroType;
        }
    }

    @Override
    public double calculateCompatibility(UsageType usage){
        switch(usage){
            case SERVER:
                return clampScore(this.getBaseScore() * 1.20);
            case DEVELOPMENT:
                return clampScore(this.getBaseScore() * 1.10);
            case GAMING:
                return clampScore(this.getBaseScore() * 0.85);
        }

        return clampScore(this.getBaseScore());
    }

    @Override
    protected String getAdditionalInfo(){
        return "Distribution: " + distroType.name();
    }

    public Distro getDistroType(){
        return distroType;
    }
}