public class MacOS extends OperatingSystem {
    private boolean hasMSeriesChip;
// public OperatingSystem(String name, String version, String kernelType, double baseScore)
    public MacOS(String name, String version, String kernelType, double baseScore, boolean hasMSeriesChip){
        super(name, version, kernelType, baseScore);
        this.hasMSeriesChip = hasMSeriesChip;
    }

    @Override
    public double calculateCompatibility(UsageType usage){
        double score = this.getBaseScore();
        switch(usage){
            case DEVELOPMENT:
                score *= 1.25;
                break;
            case GAMING:
                score *= 0.80;
                break;
        }

        if(hasMSeriesChip){
            score*=1.10;
        }

        return clampScore(score);
    }

    @Override
    public String getAdditionalInfo(){
        return "Has M-Series Chip: " + (hasMSeriesChip ? "Yes" : "No");
    }

    public boolean hasMSeriesChip(){
        return hasMSeriesChip;
    }
}