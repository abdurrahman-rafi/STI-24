public class Windows extends OperatingSystem{
    enum Edition{
        HOME, PRO, SERVER
    }

    private Edition edition;
// public OperatingSystem(String name, String version, String kernelType, double baseScore)
    public Windows(String name, String version, String kernelType, double baseScore, Edition edition){
        super(name, version, kernelType, baseScore);
        this.edition = (edition == null) ? Edition.HOME : edition;
    }

    @Override
    public double calculateCompatibility(UsageType usage){
        switch(usage){
            case SERVER:
                if(this.getEdition() == Edition.SERVER){
                    return clampScore(this.getBaseScore() * 1.30);
                }else if(this.getEdition()  == Edition.HOME){
                    return clampScore(this.getBaseScore() * 0.95);
                }
                return clampScore(this.getBaseScore());
            case GAMING:
                return clampScore(this.getBaseScore() * 1.20);
            case DEVELOPMENT:
                return clampScore(this.getBaseScore());
        }
        return clampScore(this.getBaseScore());
    }

    @Override
    protected String getAdditionalInfo(){
        return "Edition: " + edition.name();
    }

    public Edition getEdition(){
        return edition;
    }
}