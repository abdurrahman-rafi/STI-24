public class Student {
    private final String name;
    private final int age;
    private final String password;

    public Student(String name, int age, String password) {
        this.name = name.trim();
        this.age = age;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPassword() {
        return password;
    }
}
