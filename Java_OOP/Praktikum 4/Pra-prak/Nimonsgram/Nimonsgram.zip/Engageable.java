public interface Engageable {
    // 1 jika this > other, 0 jika sama, -1 jika this < other
    int compareEngagement(Engageable other);
    // public int totalScore();
}
