public interface Shareable {
    void shareTo(String target);
}
