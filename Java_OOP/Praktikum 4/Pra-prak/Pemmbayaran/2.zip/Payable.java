public interface Payable{
    void pay(int amount);
}