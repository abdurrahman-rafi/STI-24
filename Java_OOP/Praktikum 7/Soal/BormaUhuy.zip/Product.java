public interface Product {
    double getPrice();
    String getName();
}